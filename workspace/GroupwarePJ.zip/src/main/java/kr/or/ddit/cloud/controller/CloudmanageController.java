package kr.or.ddit.cloud.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CloudmanageController {
	@GetMapping("/cloud/dept")
	public String Depmanage() {
		String goPage = "DepCloud.cloud";
		return goPage;
	}
	
	@GetMapping("/cloud/team")
	public String Teammanage() {
		String goPage = "TeamCloud.cloud";
		return goPage;
	}
	
	@GetMapping("/cloud/Mem")
	public String Memmanage() {
		String goPage = "MemCloud.cloud";
		return goPage;
	}
	
}
