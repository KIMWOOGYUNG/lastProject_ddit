package kr.or.ddit.enums;

public enum ResultState {
	SUCCESSES,FAIL,OK
}
