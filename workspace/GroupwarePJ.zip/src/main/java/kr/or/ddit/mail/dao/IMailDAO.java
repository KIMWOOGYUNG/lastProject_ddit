package kr.or.ddit.mail.dao;

import kr.or.ddit.vo.EmployeeVO;

public interface IMailDAO {
 
	//메일쓰기
	public int insertmail(EmployeeVO empVO);
	
	//메일리스트 조회 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
