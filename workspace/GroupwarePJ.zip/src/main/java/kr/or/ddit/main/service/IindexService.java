package kr.or.ddit.main.service;

import java.util.List;
import java.util.Map;

public interface IindexService {
	
	// 근태 정상출근 통계
	public List<Map<String, Integer>> readNomal(String emp_code);
	
	// 근태 지각 통계 
	public List<Map<String, Integer>> readLate(String emp_code);

}
