package kr.or.ddit.face.service;

import static org.junit.Assert.*;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;

import kr.or.ddit.face.vo.FaceIdentifyResult;
import kr.or.ddit.face.vo.Person;

public class AzurePersonServiceTest {
	
	AzurePersonService personService;
	AzureFaceService faceService;
	
	Map<String, Object> responseBody;
	
	final String personGroupId = "3defb2f1-34c2-40c0-a94e-81118e6691b6"; // 1번 수행후 생성
	final String personId = "deffab75-397d-415a-be66-c014f1b963fd";// 2번 수행후 생성
	
	final String persistedFaceId = "196452f0-0af1-408f-b206-9cf9691765ae"; // 3번 수행후 생성
		
	@Before
	public void setup() {
		personService = new AzurePersonService();
		faceService = new AzureFaceService();
		responseBody = new HashMap<>();
	}

//	@Test // 1. 
	public void testCreatePersionGroup() {
		String groupId = UUID.randomUUID().toString();
		String groupName = "optionalName";
	 	int sc = personService.createPersionGroup(groupId, groupName, responseBody);
		if(sc==200) {
			System.out.println(groupId);
		}
	}

//	@Test // 2. 
	public void testCreatePersonInGroup() {
		String personName = "문재인";
		int sc = personService.createPersonInGroup(personGroupId, personName, responseBody);
		if(sc==200) {
			System.out.println(responseBody.get("personId"));
		}		
	}

//	@Test // 3.
	public void testAddFaceToPersonInGroup() throws IOException, URISyntaxException {
		byte[] imageByteArray = Files.readAllBytes(Paths.get(AzurePersonServiceTest.class.getResource("../moon01.jpg").toURI()));
		int sc = personService.addFaceToPersonInGroup(personGroupId, personId, imageByteArray, responseBody);
		if(sc==200) {
			System.out.println(responseBody.get("persistedFaceId"));
		}
	}

//	@Test // 4.
	public void testPersonGroupTrain() {
		int sc = personService.personGroupTrain(personGroupId, responseBody);
		if(sc==202) {
			System.out.println("훈련 진행 중");
		}
	}

//	@Test // 5. 
	public void testGetTrainingStatus() {
		int sc = personService.getTrainingStatus(personGroupId, responseBody);
		if(sc==200) {
			System.out.printf("훈련 상태 : %s\n", responseBody.get("status"));
		}
	}

//	@Test // 6.
	public void testFaceVerify() throws IOException, URISyntaxException {
		byte[] faceImage = Files.readAllBytes(Paths.get(AzurePersonServiceTest.class.getResource("../moon02.jpg").toURI()));
		int sc = faceService.detectFaceSimple(faceImage, responseBody);
		if(sc==200) {
			String faceId = (String)responseBody.get("faceId");
			responseBody.clear();
			sc = faceService.verifyFaceBelongToPerson(faceId, personId, personGroupId, responseBody);
			if(sc==200) {
				System.out.printf("동일인인가? %b", responseBody.get("isIdentical"));
			}
		}
		System.out.println(responseBody);	
	}
	
//	@Test // 7.
	public void testFaceIdentify() throws IOException, URISyntaxException {
		byte[] faceImage = Files.readAllBytes(Paths.get(AzurePersonServiceTest.class.getResource("../moon02.jpg").toURI()));
		int sc = faceService.detectFaceSimple(faceImage, responseBody);
		if(sc==200) {
			String faceId = (String)responseBody.get("faceId");
			responseBody.clear();
			sc = faceService.faceIdentify(faceId, personGroupId, responseBody);
			if(sc==200) {
				FaceIdentifyResult result = ((FaceIdentifyResult[]) responseBody.get("results"))[0];
				String searchedPersonId = result.getCandidates()[0].getPersonId();
				System.out.println(personId.equals(searchedPersonId)?"일치":"불일치");
				
			}
		}
		System.out.println(responseBody);	
	}
	
	@Test // 8. 1) 새로운 이미지의  faceId 를 추출하고, 2) 해당 faceId 로 personId 식별, 3)  personId로 Person 조회
	public void getPersonTest() throws IOException, URISyntaxException {
		byte[] faceImage = Files.readAllBytes(Paths.get(AzurePersonServiceTest.class.getResource("../moon02.jpg").toURI()));
		int sc = faceService.detectFaceSimple(faceImage, responseBody);
		if(sc==200) {
			String faceId = (String)responseBody.get("faceId");
			responseBody.clear();
			sc = faceService.faceIdentify(faceId, personGroupId, responseBody);
			if(sc==200) {
				FaceIdentifyResult[] results = ((FaceIdentifyResult[]) responseBody.get("results"));
				if(results!=null && results.length > 0) {
					FaceIdentifyResult face = results[0];
					String searchedPersonId = face.getCandidates()[0].getPersonId();
					long confidence = face.getCandidates()[0].getConfidence();
					responseBody.clear();
					sc = personService.getPerson(personGroupId, searchedPersonId, responseBody);
					if(sc==200) {
						Person person = (Person) responseBody.get("person");
						System.out.println(person.getName());
					}
				}
			}
		}
		System.out.println(responseBody);
	}
	
//	@Test //  번외. 등록된 Person 삭제
	public void deletePersonTest() {
		int sc = personService.deletePerson(personGroupId, personId, responseBody);
		if(sc!=200)
			System.out.println(responseBody);
	}
}




