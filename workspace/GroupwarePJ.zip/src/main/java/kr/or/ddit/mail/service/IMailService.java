package kr.or.ddit.mail.service;

import kr.or.ddit.enums.ResultState;
import kr.or.ddit.vo.EmployeeVO;

public interface IMailService {

	
	//메일쓰기
	public ResultState createmail(EmployeeVO empVO);
	
}
