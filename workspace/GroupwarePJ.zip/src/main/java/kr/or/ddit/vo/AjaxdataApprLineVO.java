package kr.or.ddit.vo;

import java.util.List;

import lombok.Data;

@Data
public class AjaxdataApprLineVO {
	
	private int rnum;
	private String line_name;
	private String line_code;
	
	private List<EmployeeVO> empList;
}
