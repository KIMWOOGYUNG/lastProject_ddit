package kr.or.ddit.mail.service;

import org.springframework.stereotype.Service;

import kr.or.ddit.enums.ResultState;
import kr.or.ddit.mail.dao.IMailDAO;
import kr.or.ddit.vo.EmployeeVO;
@Service
public class MailServiceImpl implements IMailService {
	IMailDAO dao;
	@Override
	public ResultState createmail(EmployeeVO empVO) {
		return null;
	}

}
