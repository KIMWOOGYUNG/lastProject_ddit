package kr.or.ddit.community.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ReplyController {

}
