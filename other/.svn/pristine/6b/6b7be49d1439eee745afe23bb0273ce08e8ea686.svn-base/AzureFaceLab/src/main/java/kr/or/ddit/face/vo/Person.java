package kr.or.ddit.face.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Person {
	private String personId;
	private String name;
	
	private String[] persistedFaceIds;
	
	private String userData;
}
